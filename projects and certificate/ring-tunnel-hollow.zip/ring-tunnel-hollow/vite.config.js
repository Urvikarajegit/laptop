import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig({
  plugins: [react()],
  server: {
    port: 5175,
    open: true,
  },
  resolve: {
    // Force a single Three.js instance across all packages
    dedupe: ['three'],
  },
  optimizeDeps: {
    include: [
      'three',
      '@react-three/fiber',
      '@react-three/drei',
      '@react-three/postprocessing',
      'three/examples/jsm/loaders/OBJLoader.js',
      'three/examples/jsm/utils/BufferGeometryUtils.js',
    ],
  },
  assetsInclude: ['**/*.obj', '**/*.mtl'],
})
