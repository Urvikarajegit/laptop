import { useEffect, useState } from 'react'
import * as THREE from 'three'
import { OBJLoader } from 'three/examples/jsm/loaders/OBJLoader.js'
import { mergeGeometries } from 'three/examples/jsm/utils/BufferGeometryUtils.js'

const cache = new Map()

export function useOBJ(url) {
  const [geometry, setGeometry] = useState(null)

  useEffect(() => {
    if (cache.has(url)) {
      setGeometry(cache.get(url))
      return
    }

    const loader = new OBJLoader()
    loader.load(
      url,
      (obj) => {
        // ── 1. Collect all child geometries ──────────────────
        const geos = []
        obj.traverse((child) => {
          if (child.isMesh && child.geometry) {
            geos.push(child.geometry)
          }
        })

        if (geos.length === 0) {
          console.error('useOBJ: no mesh found in', url)
          return
        }

        // ── 2. Merge (works for both indexed and non-indexed) ─
        const merged = geos.length === 1
          ? geos[0].clone()
          : mergeGeometries(geos, false)

        if (!merged) {
          console.error('useOBJ: mergeGeometries failed for', url)
          return
        }

        // ── 3. Sanitize position buffer (clamp NaN/Inf → 0) ──
        const posAttr = merged.getAttribute('position')
        if (posAttr) {
          const arr = posAttr.array
          let fixed = 0
          for (let i = 0; i < arr.length; i++) {
            if (!isFinite(arr[i])) { arr[i] = 0; fixed++ }
          }
          if (fixed > 0) {
            console.warn(`useOBJ: clamped ${fixed} NaN/Inf values in ${url}`)
            posAttr.needsUpdate = true
          }
        }

        // ── 4. Center ────────────────────────────────────────
        merged.computeBoundingBox()
        const center = new THREE.Vector3()
        merged.boundingBox.getCenter(center)
        if (isFinite(center.x) && isFinite(center.y) && isFinite(center.z)) {
          merged.translate(-center.x, -center.y, -center.z)
        }

        // ── 5. Normals & bounding sphere ─────────────────────
        merged.computeVertexNormals()
        merged.computeBoundingBox()
        merged.computeBoundingSphere()

        cache.set(url, merged)
        setGeometry(merged)
      },
      undefined,
      (err) => console.error('OBJ load error:', err)
    )
  }, [url])

  return geometry
}
