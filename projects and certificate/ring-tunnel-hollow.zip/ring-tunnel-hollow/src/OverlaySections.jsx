import React, { useEffect, useRef } from 'react'
import gsap from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'

gsap.registerPlugin(ScrollTrigger)

/**
 * Overlay sections that appear/disappear as the user scrolls.
 * Uses GSAP ScrollTrigger for precise per-section control.
 */
export default function OverlaySections() {
  const heroRef   = useRef()
  const midRef    = useRef()
  const mid2Ref   = useRef()
  const endRef    = useRef()
  const barRef    = useRef()

  useEffect(() => {
    const ctx = gsap.context(() => {
      // ── Progress bar ──────────────────────────────────────────
      gsap.to(barRef.current, {
        scaleX: 1,
        ease: 'none',
        scrollTrigger: {
          trigger:  '.scroll-driver',
          start:    'top top',
          end:      'bottom bottom',
          scrub:    true,
        },
      })
      gsap.set(barRef.current, { scaleX: 0 })

      // ── Hero: fade out as we scroll past 15% ─────────────────
      gsap.to(heroRef.current, {
        opacity:   0,
        y:         -60,
        scale:     0.88,
        ease:      'power2.in',
        scrollTrigger: {
          trigger: '.scroll-driver',
          start:   'top top',
          end:     '15% top',
          scrub:   true,
        },
      })

      // ── Mid 1: fade in at 20%, zoom in and blur out at 42% ───
      gsap.fromTo(midRef.current,
        { opacity: 0, scale: 0.7,  filter: 'blur(12px)' },
        {
          opacity: 1, scale: 1.0, filter: 'blur(0px)',
          ease:    'power2.out',
          scrollTrigger: {
            trigger: '.scroll-driver',
            start:   '20% top',
            end:     '35% top',
            scrub:   true,
          },
        }
      )
      gsap.to(midRef.current, {
        opacity: 0,
        scale:   1.35,
        filter:  'blur(10px)',
        ease:    'power2.in',
        scrollTrigger: {
          trigger: '.scroll-driver',
          start:   '42% top',
          end:     '55% top',
          scrub:   true,
        },
      })

      // ── Mid 2: fade in at 58%, out at 80% ────────────────────
      gsap.fromTo(mid2Ref.current,
        { opacity: 0, scale: 0.7,  filter: 'blur(12px)' },
        {
          opacity: 1, scale: 1.0, filter: 'blur(0px)',
          ease:    'power2.out',
          scrollTrigger: {
            trigger: '.scroll-driver',
            start:   '58% top',
            end:     '70% top',
            scrub:   true,
          },
        }
      )
      gsap.to(mid2Ref.current, {
        opacity: 0,
        scale:   1.35,
        filter:  'blur(10px)',
        ease:    'power2.in',
        scrollTrigger: {
          trigger: '.scroll-driver',
          start:   '80% top',
          end:     '88% top',
          scrub:   true,
        },
      })

      // ── End: fade in at 88%, stays sharp ─────────────────────
      gsap.fromTo(endRef.current,
        { opacity: 0, scale: 0.8, filter: 'blur(16px)' },
        {
          opacity: 1, scale: 1.0, filter: 'blur(0px)',
          ease:    'power2.out',
          scrollTrigger: {
            trigger: '.scroll-driver',
            start:   '88% top',
            end:     '96% top',
            scrub:   true,
          },
        }
      )
    })

    return () => ctx.revert()
  }, [])

  return (
    <>
      {/* ── Progress Bar ───────────────────────────────────────── */}
      <div
        ref={barRef}
        className="progress-bar"
        style={{ width: '100%' }}
      />

      {/* ── Overlay ─────────────────────────────────────────────── */}
      <div className="overlay">

        {/* Hero */}
        <div ref={heroRef} className="section-card section-hero">
          <div className="hero-badge">Ornate Ring Tunnel</div>

          <p className="hero-sub">Scroll to descend</p>
          <div className="scroll-hint">
            <div className="scroll-hint-line" />
            <span>scroll</span>
          </div>
        </div>

        {/* Mid Section 1 */}
        <div
          ref={midRef}
          className="section-card section-mid"
          style={{ opacity: 0 }}
        >
          <p className="section-label">Crafted in Gold</p>
          <h2 className="section-title">Precision<br />Meets Beauty</h2>
          <p className="section-body">
            Every detail of this ornate bearing is engineered with
            extraordinary precision — 47,936 vertices forming a symphony
            of interlocking geometry.
          </p>
        </div>

        {/* Mid Section 2 */}
        <div
          ref={mid2Ref}
          className="section-card section-mid"
          style={{ opacity: 0 }}
        >
          <p className="section-label">Deep Structure</p>
          <h2 className="section-title">62 Independent<br />Shells</h2>
          <p className="section-body">
            Beneath the surface, 51 ornate motifs rotate in perfect
            symmetry — each separated by exactly 7.06° — encircling
            the bearing's core with timeless pattern.
          </p>
        </div>

        {/* End / CTA */}
        <div
          ref={endRef}
          className="section-card section-end"
          style={{ opacity: 0 }}
        >
          <div className="hero-badge">End of the Tunnel</div>
          <h2 className="hero-title" style={{ fontSize: 'clamp(56px, 10vw, 110px)' }}>
            Beautifully<br />Engineered
          </h2>
          <p className="hero-sub" style={{ marginTop: 16 }}>
            Ornate Ring · 2026
          </p>
          <button className="cta-btn">Explore the Model</button>
        </div>

      </div>
    </>
  )
}
