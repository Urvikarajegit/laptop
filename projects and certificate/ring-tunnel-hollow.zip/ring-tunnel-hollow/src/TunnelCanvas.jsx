import React, { useRef, useCallback, useState, useEffect } from 'react'
import { Canvas, useFrame, useThree } from '@react-three/fiber'
import { EffectComposer, Bloom, Vignette } from '@react-three/postprocessing'
import * as THREE from 'three'
import RingTunnel from './RingTunnel'
import { useScrollTunnel } from './useScrollTunnel'

/* ─── Constants ─────────────────────────────────────────────────── */
const TOTAL_DEPTH  = 55
const RING_COUNT   = 14
const RING_SPACING = 4.5

/* ─── Scroll-driven camera ─────────────────────────────────────── */
function CameraRig({ scrollProgress }) {
  const { camera } = useThree()

  useFrame((_, delta) => {
    const p = scrollProgress.current
    const targetZ = 8 - p * TOTAL_DEPTH
    camera.position.z += (targetZ - camera.position.z) * Math.min(1, delta * 8)
    camera.position.x = 0
    camera.position.y = 0
    camera.lookAt(0, 0, camera.position.z - 10)
  })

  return null
}

/* ─── Effects — Crisp, pin-sharp rings with luxury Bloom & Vignette ── */
function TunnelEffects() {
  return (
    <EffectComposer multisampling={0}>
      <Bloom
        intensity={0.35}
        luminanceThreshold={0.55}
        luminanceSmoothing={0.7}
        radius={0.65}
        mipmapBlur
      />
      <Vignette eskil={false} offset={0.15} darkness={0.9} />
    </EffectComposer>
  )
}

/* ─── Lights ─────────────────────────────────────────────────────── */
function Lighting() {
  return (
    <>
      <ambientLight intensity={0.12} color="#3a2800" />
      <pointLight position={[0,   0,   7]}  intensity={5}   color="#f5c842" decay={2} />
      <pointLight position={[5,   3,  -8]}  intensity={3}   color="#c8901a" decay={2} />
      <pointLight position={[-5, -3, -20]}  intensity={2.5} color="#d4a030" decay={2} />
      <pointLight position={[0,   0, -45]}  intensity={7}   color="#ffd060" decay={1.5} />
    </>
  )
}

/* ─── Scene ──────────────────────────────────────────────────────── */
function Scene({ scrollProgress }) {
  return (
    <>
      <Lighting />
      <RingTunnel count={RING_COUNT} spacing={RING_SPACING} />
      <CameraRig scrollProgress={scrollProgress} />
      <TunnelEffects scrollProgress={scrollProgress} />
    </>
  )
}

/* ─── Canvas export ──────────────────────────────────────────────── */
export default function TunnelCanvas() {
  const scrollProgress = useRef(0)

  const handleUpdate = useCallback((p) => {
    scrollProgress.current = p
  }, [])

  useScrollTunnel({ totalDepth: TOTAL_DEPTH, onUpdate: handleUpdate })

  return (
    <Canvas
      camera={{ position: [0, 0, 8], fov: 60, near: 0.1, far: 300 }}
      gl={{
        antialias:         true,
        powerPreference:   'high-performance',
        toneMapping:       THREE.ACESFilmicToneMapping,
        toneMappingExposure: 1.3,
      }}
      dpr={[1, 1.5]}
    >
      <Scene scrollProgress={scrollProgress} />
    </Canvas>
  )
}
