import { useEffect, useRef } from 'react'
import gsap from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'

gsap.registerPlugin(ScrollTrigger)

/**
 * Hook that maps scroll progress (0→1) to a camera Z position
 * and a depth-of-field focus distance that tightens as we scroll.
 *
 * Returns: { scrollProgress (ref), dofFocus (ref) }
 */
export function useScrollTunnel({ totalDepth = 55, onUpdate }) {
  const scrollProgress = useRef(0)

  useEffect(() => {
    const trigger = ScrollTrigger.create({
      trigger:  '.scroll-driver',
      start:    'top top',
      end:      'bottom bottom',
      scrub:    0.5,
      onUpdate: (self) => {
        scrollProgress.current = self.progress
        onUpdate && onUpdate(self.progress)
      },
    })

    return () => trigger.kill()
  }, [totalDepth, onUpdate])

  return { scrollProgress }
}
