import React, { useRef, useMemo } from 'react'
import { useFrame, useThree } from '@react-three/fiber'
import { useOBJ } from './useOBJ'
import * as THREE from 'three'

/**
 * Single ring instance — clones the loaded geometry,
 * applies gold material, and spins at a constant rate.
 */
function RingInstance({ position, scale, rotationOffset = 0 }) {
  const meshRef = useRef()
  const geometry = useOBJ('/models/reference_style_bearing.obj')

  const material = useMemo(() => new THREE.MeshStandardMaterial({
    color:     new THREE.Color(0.83, 0.52, 0.08),
    metalness: 0.85,
    roughness: 0.18,
    envMapIntensity: 1.2,
    side:      THREE.DoubleSide,
  }), [])

  useFrame((_, delta) => {
    if (meshRef.current) {
      meshRef.current.rotation.z += delta * 0.12
    }
  })

  if (!geometry) return null

  return (
    <mesh
      ref={meshRef}
      geometry={geometry}
      material={material}
      position={position}
      scale={[scale, scale, scale]}
      rotation={[0, 0, rotationOffset]}
    />
  )
}

/** Tunnel — places N rings along negative Z. */
export default function RingTunnel({ count = 14, spacing = 4.5 }) {
  const rings = useMemo(() => {
    return Array.from({ length: count }, (_, i) => ({
      id:             i,
      z:              -i * spacing,
      scale:          1.0,
      rotationOffset: (i * Math.PI * 2) / count,
    }))
  }, [count, spacing])

  return (
    <group>
      {rings.map(r => (
        <RingInstance
          key={r.id}
          position={[0, 0, r.z]}
          scale={r.scale}
          rotationOffset={r.rotationOffset}
        />
      ))}
    </group>
  )
}
