import React, { Suspense } from 'react'
import TunnelCanvas    from './TunnelCanvas'
import OverlaySections from './OverlaySections'

function LoadingScreen() {
  return (
    <div style={{
      position:   'fixed',
      inset:      0,
      background: '#0a0700',
      display:    'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
      gap: 24,
      zIndex: 999,
      fontFamily: 'Inter, sans-serif',
    }}>
      <div style={{
        width:  48,
        height: 48,
        border: '2px solid rgba(201,168,76,0.2)',
        borderTop: '2px solid #c9a84c',
        borderRadius: '50%',
        animation: 'spin 1s linear infinite',
      }} />
      <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
      <p style={{
        fontSize:      11,
        letterSpacing: '3px',
        textTransform: 'uppercase',
        color:         'rgba(201,168,76,0.6)',
      }}>Loading Ring Tunnel…</p>
    </div>
  )
}

export default function App() {
  return (
    <>
      {/* Long scrollable page to drive camera */}
      <div className="scroll-driver" />

      {/* Fixed 3-D Canvas */}
      <div className="canvas-wrapper">
        <Suspense fallback={<LoadingScreen />}>
          <TunnelCanvas />
        </Suspense>
      </div>

      {/* Fixed HTML overlay — text sections */}
      <OverlaySections />
    </>
  )
}
